import sqlite3

conn = sqlite3.connect('movies.db')
# create a cursor
c = conn.cursor()

# create a table
'''c.execute("""CREATE TABLE tb(
        moviename text,
        actorname text,
        actressname text,
        releaseyear text,
        directorname
    )""")'''

# Insert Record
'''c.execute("INSERT INTO tb VALUES ('Sooryavanshi','	Akshay Kumar','Katrina Kaif','2021','	Rohit Shetty')")
c.execute("INSERT INTO tb VALUES ('Spider-Man: No Way Home','Tom Holland','Zendaya','2021','	Jon Watts')")
c.execute("INSERT INTO tb VALUES ('pushpa','allu arjun','rashmika mandana','2021','sukumar')")
c.execute("INSERT INTO tb VALUES ('Bulbbul','Avinash Tiwary','Tripti Dimri','2020','Anvita Dutt')")
'''

# update
'''c.execute("""UPDATE tb SET actressname='Deepika'
    WHERE moviename = 'Sooryavanshi'
    """)
'''
# delete
'''c.execute("DELETE from tb WHERE moviename = 'Bulbbul'") '''

# drop
'''c.execute("DROP TABLE tb")'''

c.execute("SELECT * FROM tb")

fields = c.fetchall()
for field in fields:
    print(field)

conn.commit()

conn.close()